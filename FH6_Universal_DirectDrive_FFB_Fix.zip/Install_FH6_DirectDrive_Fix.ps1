param(
    [switch]$Uninstall,
    [switch]$AutoMode,
    [switch]$Force
)

$ErrorActionPreference = 'Stop'
$scriptRoot = $PSScriptRoot
$configIniPath = Join-Path $scriptRoot "config\DirectDrive_Physics.ini"
$targetWheelsPath = Join-Path $scriptRoot "config\Target_Wheels.json"

if (-not $AutoMode) {
    Write-Host "================================================================" -ForegroundColor Cyan
    Write-Host "  Forza Horizon 6 - Universal Direct Drive FFB Physics Patcher  " -ForegroundColor Cyan
    Write-Host "================================================================" -ForegroundColor Cyan
    Write-Host ""
}

# 1. Auto-detect Forza Horizon 6 installation directory (MS Store / Xbox App or Steam)
$mediaDir = $null
$candidates = @(
    "C:\XboxGames\Forza Horizon 6\Content\media",
    "D:\XboxGames\Forza Horizon 6\Content\media",
    "E:\XboxGames\Forza Horizon 6\Content\media",
    "F:\XboxGames\Forza Horizon 6\Content\media",
    "C:\Program Files (x86)\Steam\steamapps\common\ForzaHorizon6\media",
    "D:\SteamLibrary\steamapps\common\ForzaHorizon6\media",
    "E:\SteamLibrary\steamapps\common\ForzaHorizon6\media"
)

try {
    $pkg = Get-AppxPackage -Name "Microsoft.ForteBaseGame*" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($pkg -and $pkg.InstallLocation) {
        $candidates = @("$($pkg.InstallLocation)\media") + $candidates
    }
} catch {}

foreach ($c in $candidates) {
    if ($c -and (Test-Path "$c\wheeltunablesettingspc.zip")) {
        $mediaDir = $c
        break
    }
}

if (-not $mediaDir -and (-not $AutoMode)) {
    Write-Host "Could not auto-detect Forza Horizon 6 folder. Please select the 'Forza Horizon 6' folder..." -ForegroundColor Yellow
    Add-Type -AssemblyName System.Windows.Forms
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = "Select your Forza Horizon 6 installation folder (or Content\media folder)"
    if ($dlg.ShowDialog() -eq 'OK') {
        if (Test-Path "$($dlg.SelectedPath)\wheeltunablesettingspc.zip") {
            $mediaDir = $dlg.SelectedPath
        } elseif (Test-Path "$($dlg.SelectedPath)\Content\media\wheeltunablesettingspc.zip") {
            $mediaDir = "$($dlg.SelectedPath)\Content\media"
        } elseif (Test-Path "$($dlg.SelectedPath)\media\wheeltunablesettingspc.zip") {
            $mediaDir = "$($dlg.SelectedPath)\media"
        }
    }
}

if (-not $mediaDir -or -not (Test-Path "$mediaDir\wheeltunablesettingspc.zip")) {
    if (-not $AutoMode) {
        Write-Host "ERROR: Could not find wheeltunablesettingspc.zip. Exiting." -ForegroundColor Red
    }
    exit 1
}

$wtsPath = "$mediaDir\wheeltunablesettingspc.zip"
$impPath = "$mediaDir\inputmappingprofiles.zip"
$backupDir = "$env:USERPROFILE\Documents\FH6_DirectDrive_FFB_Backup"
$logPath = "$backupDir\patch_history.log"
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null

if ($Uninstall) {
    if (Test-Path "$backupDir\wheeltunablesettingspc_stock.zip") {
        Copy-Item "$backupDir\wheeltunablesettingspc_stock.zip" $wtsPath -Force
        Write-Host "Restored stock wheeltunablesettingspc.zip" -ForegroundColor Green
    }
    if (Test-Path "$backupDir\inputmappingprofiles_stock.zip") {
        Copy-Item "$backupDir\inputmappingprofiles_stock.zip" $impPath -Force
        Write-Host "Restored stock inputmappingprofiles.zip" -ForegroundColor Green
    }
    Unregister-ScheduledTask -TaskName "FH6_Universal_DD_AutoPatcher" -Confirm:$false -ErrorAction SilentlyContinue
    Unregister-ScheduledTask -TaskName "FH6_Simucube3_AutoPatcher" -Confirm:$false -ErrorAction SilentlyContinue
    Write-Host "Removed auto-update task and restored stock files." -ForegroundColor Cyan
    exit 0
}

# 2. Load config/Target_Wheels.json and config/DirectDrive_Physics.ini
$targetsConfig = Get-Content $targetWheelsPath -Raw | ConvertFrom-Json
$baseDdTemplate = Get-Content $configIniPath -Raw

# Auto-detect connected Direct Drive wheelbase USB VID/PID for inputmappingprofiles.zip (defaults to Simucube 3 Pro 0x16d00d66)
$activeWheel = $targetsConfig.default_input_mapping_wheel
try {
    $presentPnp = Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue | Select-Object -ExpandProperty InstanceId
    foreach ($wb in $targetsConfig.auto_detect_wheelbases) {
        if ($presentPnp | Where-Object { $_ -match $wb.pnp_match }) {
            $activeWheel = $wb
            break
        }
    }
} catch {}

# 3. Fast check (~30ms): see if wheeltunablesettingspc.zip and inputmappingprofiles.zip are already patched
$wtsBytes = [System.IO.File]::ReadAllBytes($wtsPath)
$wtsText = [System.Text.Encoding]::ASCII.GetString($wtsBytes)
$hasSc3InWts = ([regex]::IsMatch($wtsText, "(?i)ControllerFFB-0X16D00D66\.ini"))
$needsWtsPatch = $Force -or (-not $hasSc3InWts)

$needsImpPatch = $Force
if ((-not $needsImpPatch) -and (Test-Path $impPath)) {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [System.IO.Compression.ZipFile]::OpenRead($impPath)
    try {
        $entry = $zip.GetEntry("CustomRawGameControllerProfile1.xml")
        if ($entry) {
            $sr = New-Object System.IO.StreamReader($entry.Open())
            $xmlTxt = $sr.ReadToEnd()
            $sr.Close()
            if (-not $xmlTxt.Contains($activeWheel.vid_pid_hex)) {
                $needsImpPatch = $true
            }
        }
    } finally {
        $zip.Dispose()
    }
}

# Self-healing stock backups: if an archive in the game folder is currently unpatched (e.g. fresh install or just updated by Xbox/Steam),
# refresh the saved *_stock.zip backup BEFORE patching so Uninstall always restores the latest game version's stock archive!
if (-not $hasSc3InWts) {
    Copy-Item $wtsPath "$backupDir\wheeltunablesettingspc_stock.zip" -Force
}
if ($needsImpPatch -and (Test-Path $impPath) -and (-not $Force)) {
    Copy-Item $impPath "$backupDir\inputmappingprofiles_stock.zip" -Force
}

# Check if Playground Games officially added ControllerFFB-0X16D00D66.ini in a new Forza update!
if ($needsImpPatch -and $hasSc3InWts -and (-not $Force)) {
    $stamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    Add-Content -Path $logPath -Value "[$stamp] DETECTED OFFICIAL SIMUCUBE 3 PRO SUPPORT IN FORZA UPDATE! Leaving official ControllerFFB-0X16D00D66.ini untouched so you can test it."
    Add-Type -AssemblyName PresentationFramework
    [System.Windows.MessageBox]::Show(
        "The latest Forza Horizon 6 update officially added a Simucube 3 Pro profile (ControllerFFB-0X16D00D66.ini)!`n`nThe auto-patcher left Playground Games' new official SC3 profile untouched so you can try it out.",
        "Forza Horizon 6 - Official Simucube 3 Pro Support Added!",
        "OK",
        "Information"
    ) | Out-Null
}

if ((-not $needsWtsPatch) -and (-not $needsImpPatch)) {
    if (-not $AutoMode) {
        Write-Host "Forza Horizon 6 archives are already patched and up to date for $($activeWheel.name) ($($activeWheel.vid_pid_hex))." -ForegroundColor Green
    }
    exit 0
}

if (-not $AutoMode) {
    Write-Host "Found Forza Horizon 6 media directory: $mediaDir" -ForegroundColor Green
    Write-Host "Target Primary FFB Wheelbase: $($activeWheel.name) ($($activeWheel.vid_pid_hex))" -ForegroundColor Cyan
    Write-Host ""
}

# 4. Compile Forza's 4096-byte page-aligned zip patcher (0x1123 extra field TLV)
Add-Type -ReferencedAssemblies "System.IO.Compression" -TypeDefinition @"
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Text;

public class ForzaZipPatcher {
    public class RawEntry {
        public string Name;
        public ushort VerMade;
        public ushort VerNeed;
        public ushort Flags;
        public ushort Method;
        public uint DosTime;
        public uint Crc32;
        public byte[] CompressedData;
        public byte[] UncompressedData;
    }

    private static uint ComputeCrc32(byte[] data) {
        uint crc = 0xFFFFFFFF;
        for (int i = 0; i < data.Length; i++) {
            crc ^= data[i];
            for (int j = 0; j < 8; j++) {
                if ((crc & 1) != 0) crc = (crc >> 1) ^ 0xEDB88320;
                else crc >>= 1;
            }
        }
        return ~crc;
    }

    public static byte[] DeflateRaw(byte[] raw) {
        using (var ms = new MemoryStream()) {
            using (var ds = new DeflateStream(ms, CompressionLevel.Optimal, true)) {
                ds.Write(raw, 0, raw.Length);
            }
            return ms.ToArray();
        }
    }

    public static List<RawEntry> ReadForzaZip(string path) {
        byte[] bytes = File.ReadAllBytes(path);
        int eocd = -1;
        for (int i = bytes.Length - 22; i >= 0; i--) {
            if (bytes[i] == 0x50 && bytes[i+1] == 0x4B && bytes[i+2] == 0x05 && bytes[i+3] == 0x06) {
                eocd = i;
                break;
            }
        }
        ushort count = BitConverter.ToUInt16(bytes, eocd + 10);
        uint cdOffset = BitConverter.ToUInt32(bytes, eocd + 16);
        int pos = (int)cdOffset;
        var list = new List<RawEntry>();
        for (int k = 0; k < count; k++) {
            ushort verMade = BitConverter.ToUInt16(bytes, pos + 4);
            ushort verNeed = BitConverter.ToUInt16(bytes, pos + 6);
            ushort flags = BitConverter.ToUInt16(bytes, pos + 8);
            ushort method = BitConverter.ToUInt16(bytes, pos + 10);
            uint dosTime = BitConverter.ToUInt32(bytes, pos + 12);
            uint crc = BitConverter.ToUInt32(bytes, pos + 16);
            uint compLen = BitConverter.ToUInt32(bytes, pos + 20);
            uint uncompLen = BitConverter.ToUInt32(bytes, pos + 24);
            ushort nameLen = BitConverter.ToUInt16(bytes, pos + 28);
            ushort extraLen = BitConverter.ToUInt16(bytes, pos + 30);
            ushort commentLen = BitConverter.ToUInt16(bytes, pos + 32);
            uint localHeaderOffset = BitConverter.ToUInt32(bytes, pos + 42);
            string name = Encoding.ASCII.GetString(bytes, pos + 46, nameLen);

            ushort localNameLen = BitConverter.ToUInt16(bytes, (int)localHeaderOffset + 26);
            ushort localExtraLen = BitConverter.ToUInt16(bytes, (int)localHeaderOffset + 28);
            int dataStart = (int)localHeaderOffset + 30 + localNameLen + localExtraLen;

            byte[] compData = new byte[compLen];
            Array.Copy(bytes, dataStart, compData, 0, (int)compLen);

            byte[] uncompData;
            using (var msIn = new MemoryStream(compData))
            using (var ds = new DeflateStream(msIn, CompressionMode.Decompress))
            using (var msOut = new MemoryStream()) {
                ds.CopyTo(msOut);
                uncompData = msOut.ToArray();
            }

            list.Add(new RawEntry {
                Name = name,
                VerMade = verMade,
                VerNeed = verNeed,
                Flags = flags,
                Method = method,
                DosTime = dosTime,
                Crc32 = crc,
                CompressedData = compData,
                UncompressedData = uncompData
            });

            pos += 46 + nameLen + extraLen + commentLen;
        }
        return list;
    }

    public static void UpdateEntryText(RawEntry entry, string newText) {
        byte[] raw = Encoding.UTF8.GetBytes(newText);
        entry.UncompressedData = raw;
        entry.Crc32 = ComputeCrc32(raw);
        entry.CompressedData = DeflateRaw(raw);
    }

    public static void WriteForzaZip(string outPath, List<RawEntry> entries) {
        using (var ms = new MemoryStream())
        using (var bw = new BinaryWriter(ms)) {
            var localOffsets = new List<uint>();
            var dataOffsets = new List<uint>();

            foreach (var e in entries) {
                uint localHeaderOffset = (uint)ms.Position;
                localOffsets.Add(localHeaderOffset);

                byte[] nameBytes = Encoding.ASCII.GetBytes(e.Name);
                uint minEnd = localHeaderOffset + 30 + (uint)nameBytes.Length + 4;
                uint alignedDataStart = ((minEnd + 4095) / 4096) * 4096;
                ushort extraLen = (ushort)(alignedDataStart - (localHeaderOffset + 30 + (uint)nameBytes.Length));
                dataOffsets.Add(alignedDataStart);

                bw.Write((uint)0x04034B50);
                bw.Write(e.VerNeed);
                bw.Write(e.Flags);
                bw.Write(e.Method);
                bw.Write(e.DosTime);
                bw.Write(e.Crc32);
                bw.Write((uint)e.CompressedData.Length);
                bw.Write((uint)e.UncompressedData.Length);
                bw.Write((ushort)nameBytes.Length);
                bw.Write(extraLen);
                bw.Write(nameBytes);

                bw.Write((ushort)0x1123);
                bw.Write((ushort)(extraLen - 4));
                bw.Write(new byte[extraLen - 4]);

                bw.Write(e.CompressedData);
            }

            uint cdStart = (uint)ms.Position;
            for (int i = 0; i < entries.Count; i++) {
                var e = entries[i];
                byte[] nameBytes = Encoding.ASCII.GetBytes(e.Name);
                bw.Write((uint)0x02014B50);
                bw.Write(e.VerMade);
                bw.Write(e.VerNeed);
                bw.Write(e.Flags);
                bw.Write(e.Method);
                bw.Write(e.DosTime);
                bw.Write(e.Crc32);
                bw.Write((uint)e.CompressedData.Length);
                bw.Write((uint)e.UncompressedData.Length);
                bw.Write((ushort)nameBytes.Length);
                bw.Write((ushort)8);
                bw.Write((ushort)0);
                bw.Write((ushort)0);
                bw.Write((ushort)0);
                bw.Write((uint)0);
                bw.Write(localOffsets[i]);
                bw.Write(nameBytes);
                bw.Write((ushort)0x1123);
                bw.Write((ushort)4);
                bw.Write(dataOffsets[i]);
            }
            uint cdEnd = (uint)ms.Position;
            uint cdSize = cdEnd - cdStart;

            bw.Write((uint)0x06054B50);
            bw.Write((ushort)0);
            bw.Write((ushort)0);
            bw.Write((ushort)entries.Count);
            bw.Write((ushort)entries.Count);
            bw.Write(cdSize);
            bw.Write(cdStart);
            bw.Write((ushort)0);

            bw.Flush();
            File.WriteAllBytes(outPath, ms.ToArray());
        }
    }
}
"@

function Build-CleanDdIni([string]$vendorProd, [string]$friendlyName, [string]$dynScale = "1", [bool]$omitDor = $false) {
    $txt = $baseDdTemplate -replace "`r?`n", "`r`n"
    $txt = $txt -replace '(?m)^VendorProduct\s+.*$', "VendorProduct $vendorProd"
    $txt = $txt -replace '(?m)^FriendlyName\s+.*$', "FriendlyName $friendlyName"
    $txt = $txt -replace '(?m)^DynFFBScale\s+.*$', "DynFFBScale $dynScale"
    if ($omitDor) {
        $txt = $txt -replace '(?m)^DegreesOfRotation\s+.*\r?\n', ''
    }
    return $txt
}

# 5. Patch inputmappingprofiles.zip (ensures multi-USB rigs like Simucube 3 + Fanatec Pedals route FFB to the wheelbase)
if ($needsImpPatch -and (Test-Path $impPath)) {
    $impEntries = [ForzaZipPatcher]::ReadForzaZip($impPath)
    foreach ($e in $impEntries) {
        if ($e.Name -match "^CustomRawGameControllerProfile[1-5]\.xml$") {
            $txt = [System.Text.Encoding]::UTF8.GetString($e.UncompressedData)
            $txt = $txt -replace 'PrimaryDeviceVidPid="[^"]+"', "PrimaryDeviceVidPid=`"$($activeWheel.vid_pid_hex)`""
            $txt = $txt -replace 'FFBDeviceVidPid="[^"]+"', "FFBDeviceVidPid=`"$($activeWheel.vid_pid_hex)`""
            [ForzaZipPatcher]::UpdateEntryText($e, $txt)
        }
        elseif ($e.Name -match "^CustomWheelMappingProfile[1-5]\.xml$") {
            $txt = [System.Text.Encoding]::UTF8.GetString($e.UncompressedData)
            $txt = $txt -replace 'WheelVidPid="[^"]+"', "WheelVidPid=`"$($activeWheel.vid_pid_dec)`""
            [ForzaZipPatcher]::UpdateEntryText($e, $txt)
        }
    }
    [ForzaZipPatcher]::WriteForzaZip($impPath, $impEntries)
    if (-not $AutoMode) {
        Write-Host "  Patched inputmappingprofiles.zip -> FFBDeviceVidPid=$($activeWheel.vid_pid_hex)" -ForegroundColor Green
    }
}

# 6. Patch wheeltunablesettingspc.zip from config/DirectDrive_Physics.ini & config/Target_Wheels.json
if ($needsWtsPatch) {
    $wtsEntries = [ForzaZipPatcher]::ReadForzaZip($wtsPath)
    $sc2Entry = $wtsEntries | Where-Object { $_.Name -ieq "ControllerFFB-0X16D00D60.ini" } | Select-Object -First 1

    foreach ($upg in $targetsConfig.upgrade_existing_ini_files) {
        $e = $wtsEntries | Where-Object { $_.Name -ieq $upg.file } | Select-Object -First 1
        if ($e) {
            $newTxt = Build-CleanDdIni $upg.vendor_product $upg.friendly_name $upg.dyn_ffb_scale ([bool]$upg.omit_dor)
            [ForzaZipPatcher]::UpdateEntryText($e, $newTxt)
            if (-not $AutoMode) {
                Write-Host "  Upgraded $($e.Name) ($($upg.friendly_name)) -> Clean Modern DD Physics" -ForegroundColor Green
            }
        }
    }

    foreach ($add in $targetsConfig.inject_new_ini_files) {
        $existing = $wtsEntries | Where-Object { $_.Name -ieq $add.file } | Select-Object -First 1
        $newTxt = Build-CleanDdIni $add.vendor_product $add.friendly_name $add.dyn_ffb_scale $false
        if ($existing) {
            [ForzaZipPatcher]::UpdateEntryText($existing, $newTxt)
        } elseif ($sc2Entry) {
            $newEntry = New-Object ForzaZipPatcher+RawEntry
            $newEntry.Name = $add.file
            $newEntry.VerMade = $sc2Entry.VerMade
            $newEntry.VerNeed = $sc2Entry.VerNeed
            $newEntry.Flags = $sc2Entry.Flags
            $newEntry.Method = $sc2Entry.Method
            $newEntry.DosTime = $sc2Entry.DosTime
            [ForzaZipPatcher]::UpdateEntryText($newEntry, $newTxt)
            $idx = $wtsEntries.IndexOf($sc2Entry)
            $wtsEntries.Insert($idx + 1, $newEntry)
            if (-not $AutoMode) {
                Write-Host "  Added $($add.file) ($($add.friendly_name)) -> Clean Modern DD Physics" -ForegroundColor Green
            }
        }
    }

    [ForzaZipPatcher]::WriteForzaZip($wtsPath, $wtsEntries)
}

$stamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
Add-Content -Path $logPath -Value "[$stamp] Applied Universal DD FFB patch (WTS=$needsWtsPatch, IMP=$needsImpPatch, Wheel=$($activeWheel.name))"

if ($AutoMode) {
    exit 0
}

Write-Host ""
Write-Host "Successfully patched Forza Horizon 6 archives (4096-byte page aligned)!" -ForegroundColor Cyan
Write-Host ""

# 7. Optional prompt to enable automatic re-patching after Forza Horizon 6 updates
$ans = Read-Host "Would you like to automatically re-apply this patch whenever Forza Horizon 6 updates? (y/N)"
if ($ans -match "^[Yy]") {
    $taskName = "FH6_Universal_DD_AutoPatcher"
    $action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$PSCommandPath`" -AutoMode"
    $CIMTriggerClass = Get-CimClass -ClassName MSFT_TaskEventTrigger -Namespace Root/Microsoft/Windows/TaskScheduler
    $triggerAppX = New-CimInstance -CimClass $CIMTriggerClass -ClientOnly
    $triggerAppX.Subscription = @"
<QueryList><Query Id="0" Path="Microsoft-Windows-AppXDeploymentServer/Operational"><Select Path="Microsoft-Windows-AppXDeploymentServer/Operational">*[System[Provider[@Name='Microsoft-Windows-AppXDeployment-Server'] and (EventID=400 or EventID=613)]]</Select></Query></QueryList>
"@
    $triggerAppX.Enabled = $true
    $triggerTime = New-ScheduledTaskTrigger -Daily -At "12:00PM"
    $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Minutes 2)

    Register-ScheduledTask -TaskName $taskName -Action $action -Trigger @($triggerAppX, $triggerTime) -Settings $settings -Description "Automatically re-applies Universal Direct Drive FFB physics & input mapping patch after Forza Horizon 6 game updates." -Force | Out-Null
    Write-Host "Enabled automatic update protection (Task: $taskName)!" -ForegroundColor Green
}

Write-Host ""
Write-Host "Done! Restart Forza Horizon 6 to feel the updated Direct Drive physics." -ForegroundColor Green
